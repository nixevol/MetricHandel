# MetricHandel
## 运行说明

### 安装依赖

```bash
pip install -r requirements.txt
```

### 运行程序

```bash
python main.py
```

程序启动后会自动在浏览器中打开 `http://127.0.0.1:8000`

